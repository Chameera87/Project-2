import java.util.Scanner;

/**
 * Snakes and Ladders game, completed.
 * @author Robyn Gibson
 * @author Julian Dermoudy
 * @author James Montgomery
 * @version 3.1 (April 2014)
 */
public class SALGame {
    private int playerNum;      //to record the current player
    private int p1position;     //player 1 counter
    private int p2position;     //player 2 counter
    private Die roller;          //the virtual Die
    private Board gameBoard;    //the virtual Board
    private boolean tracing;     //switch for trace messages
    private Scanner sc;            //scanner object for keyboard input

    /**
     * Creates a new Snakes & Ladders game by creating a new game board and
     * die. The game is ready to be played at the end of this.
     */
    public SALGame() {
        sc = new Scanner(System.in);
        roller = new Die();
        gameBoard = new Board();
        startPlaying();
    }

    /**
     * Controls the "outer loop" of the game; calls playGame() to play each
     * individual game.
     */
    public void startPlaying() {
        char ans;
        final char YES = 'y';

        System.out.print("Do you want to play Snakes and Ladders? (y/n) ");
        ans = sc.next().toLowerCase().charAt(0);
        while (ans == YES) {
            playGame();
            System.out.print("Do you want to play again? (y/n) ");
            ans = sc.next().toLowerCase().charAt(0);
        }
    }

    /**
     * Plays one game; calls makeAMove() for each move and swapPlayer when
     * necessary.
     */
    public void playGame() {
        boolean over;

        trace("game started");
        over = false;
        p1position = 0;
        p2position = 0;
        playerNum = 1;
        while (!over) {
            System.out.println();
            over = makeAMove(playerNum);
            if (!over) {
                swapPlayer();
            }
        }
        System.out.println("winner of this game is player: " + playerNum);
    }

    /**
     * Changes the value of the counter for the given player. Uses roll method of
     * the Die to find distance to move and moveOn method of the Board to find
     * new position for the player.
     * @param player - the current player
     * @return true if the game is now over, false otherwise
     */
    public boolean makeAMove(int player) {
        int dieRolled;
        int lastPosition;
        boolean finished = false; //must be or this would not have been called

        lastPosition = gameBoard.getLastSquare();
        System.out.println();
        System.out.println("Current Player: " + player);
        dieRolled = roller.roll();

        //Note: this could be improved if players were actual objects since could
        // simply "point" to the current player below and only write the code once.
        switch (player) {
            case 1: System.out.println("Start at position: " + p1position);
                    System.out.println("Die roll is: " + dieRolled);
                    p1position = gameBoard.moveOn(p1position, dieRolled);
                    System.out.println("Now at position: " + p1position);
                    break;
            case 2: System.out.println("Start at position: " + p2position);
                    System.out.println("Die roll is: " + dieRolled);
                    p2position = gameBoard.moveOn(p2position, dieRolled);
                    System.out.println("Now at position: " + p2position);
                    break;
        }

        if (p1position == lastPosition || p2position == lastPosition) {
            finished = true;
        }
        //Alternatively, in one line (in fact, this would be preferred):
        //return p1position == lastPosition || p2position == lastPosition;

        return finished;
    }

    /**
     * Swaps the current player by changing the value of the instance variable
     * playerNum.
     */
    public void swapPlayer() {
        if (playerNum == 1) {
            playerNum = 2;
        } else {
            playerNum = 1;
        }
    }

    /**
     * Displays a tracing (i.e., debug) message to standard output if the
     * instance variable trace is true.
     * @param message the debugging message to output
     */
    public void trace(String message) {
        if (tracing) {
            System.out.println(message);
        }
    }

    /**
     * Sets whether or not tracing messages will be displayed (by modifying the
     * tracing instance variable).
     * @param on if true tracing messags will be displayed
     */
    public void setTracing(boolean on) {
        tracing = on;
    }

}
